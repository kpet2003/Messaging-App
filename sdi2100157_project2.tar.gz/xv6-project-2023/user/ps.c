#include "kernel/types.h"
#include "kernel/pstat.h"
#include "kernel/stat.h"
#include "user/user.h"



void ps(void) {
    struct pstat* st = malloc(sizeof(struct  pstat));

    getpinfo(st);
    printf("NAME \t PID \t PPID\t PRIORITY\t SIZE\t \tSTATE\n");
    for(int i=0; i<st->size; i++) {
        printf("%s\t %d\t %d\t %d\t\t %d\t",st->name[i],st->pid[i],st->ppid[i],st->priority[i],st->proc_size[i]);
        if(st->state[i]==1) {
            printf("\tUSED\t");
        }
        else if(st->state[i]==2) {
            printf("\tSLEEPING\t");
        }
        else if(st->state[i]==3) {
            printf("\tRUNNABLE\t");
        }
        else if(st->state[i]==4) {
            printf("\tRUNNING\t");
        }
         else if(st->state[i]==4) {
            printf("\tZOMBIE\t");
        }
        printf("\n");

    }
    free(st);
}


int main(int argc,char** argv) {
    ps();
    exit(0);
}