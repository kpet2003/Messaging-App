
#define NPROC        64  // maximum number of processes
#include "types.h"

// we save the attributes of each active process in the appropriate array
struct pstat {
  int size;   // size of the struct;

   int pid[NPROC];   
  int state[NPROC]; 
 
  char name[NPROC][16];
  int ppid[NPROC];  // parent pid
  int priority[NPROC];
  uint64 proc_size[NPROC];  // size of each process
};

